//
//  ViewController.swift
//  SoptThirdSeminar
//
//  Created by Junhyeon on 2019/10/26.
//  Copyright © 2019 Junhyeon. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

