//
//  BannerViewCell.swift
//  SoptSecondStackView
//
//  Created by Junhyeon on 2019/10/26.
//  Copyright © 2019 Junhyeon. All rights reserved.
//

import UIKit

class BannerCell: UICollectionViewCell {
    
    @IBOutlet var Banner: UIImageView?
    
}
