//
//  UITextField+Extension.swift
//  SoptSecondStackView
//
//  Created by Junhyeon on 2019/10/16.
//  Copyright © 2019 Junhyeon. All rights reserved.
//

import Foundation
